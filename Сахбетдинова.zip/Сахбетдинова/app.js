document.addEventListener('DOMContentLoaded', function() {
  const slides = document.querySelectorAll('.slide');
  const dotsContainer = document.querySelector('.slider-dots');
  const prevArrow = document.querySelector('.prev-arrow');
  const nextArrow = document.querySelector('.next-arrow');
  let currentSlide = 0;
  let slideInterval;
  
  function createDots() {
      slides.forEach((_, index) => {
          const dot = document.createElement('div');
          dot.classList.add('dot');
          if (index === currentSlide) dot.classList.add('active');
          dot.addEventListener('click', () => goToSlide(index));
          dotsContainer.appendChild(dot);
      });
  }
  
  function goToSlide(index) {
      slides[currentSlide].classList.remove('active');
      
      currentSlide = (index + slides.length) % slides.length;
      
      slides[currentSlide].classList.add('active');
      updateDots();
  }
  
  function updateDots() {
      const dots = document.querySelectorAll('.dot');
      dots.forEach((dot, index) => {
          dot.classList.toggle('active', index === currentSlide);
      });
  }
  
  function startAutoSlide() {
      slideInterval = setInterval(() => {
          goToSlide(currentSlide + 1);
      }, 5000);
  }
  
  function initSlider() {
      createDots();
      startAutoSlide();
      
      prevArrow.addEventListener('click', () => {
          clearInterval(slideInterval);
          goToSlide(currentSlide - 1);
          startAutoSlide();
      });
      
      nextArrow.addEventListener('click', () => {
          clearInterval(slideInterval);
          goToSlide(currentSlide + 1);
          startAutoSlide();
      });
      
      const slider = document.querySelector('.slider-container');
      slider.addEventListener('mouseenter', () => {
          clearInterval(slideInterval);
      });
      
      slider.addEventListener('mouseleave', startAutoSlide);
  }
  
  initSlider();
});